"""Apply the pinned V1.0.2 visual decisions to an independent test candidate."""

from copy import deepcopy


ETF_ID = "E-SEP-ETF-01"
TURNOVER_ID = "E-SEP-TURNOVER-01"
PMI_ID = "E-AUG-01-03"
SOURCES = {
    ETF_ID: ["V102-ETF-CSJ-CNS", "V102-ETF-CSJ-PDF", "V102-ETF-CNS-0928"],
    TURNOVER_ID: ["V102-TURNOVER-CNS", "V102-TURNOVER-21CJ"],
}


def _prepare_reading(cue, text_in, exit_start, fps, caption_roles=None):
    end = cue["end_frame_exclusive"]
    full = text_in + 6
    if not cue["start_frame"] <= text_in < full < exit_start < end:
        raise ValueError(f"Invalid reading and exit windows: {cue['shot_id']}")
    text = cue["text_cue"]
    text.update(
        in_frame=text_in, full_alpha_from_frame=full, out_frame_exclusive=end,
        stable_reading_seconds=(exit_start - full) / fps,
    )
    story = cue["camera_story_clock"]
    story.update(reading_window=[full, exit_start], exit_window=[exit_start, end],
                 focus_exit_frame=exit_start)
    if caption_roles is not None:
        story["caption_hierarchy"] = [
            {"text": line, "role": role}
            for line, role in zip(text["lines"], caption_roles, strict=True)
        ]


def _with_pmi_timeline(cue, registry_record, fps):
    event = cue["event_clock"]
    if (
        event["event_id"] != PMI_ID or registry_record["date"] != "2015-08-21"
        or registry_record["time"] != "09:43:10" or registry_record["first_release_time"] is not None
        or (event["date"], event["time"], event["first_release_time"])
        != (registry_record["date"], registry_record["time"], None)
        or not all(point["date"] == registry_record["date"] for point in cue["market_clock"]["keyframes"])
    ):
        raise ValueError("PMI dual-timeline decision requires the pinned webpage time and one complete 8/21 bar.")
    event.update(
        timeline_points=[
            {"date": registry_record["date"], "time": "09:30",
             "role": "market_open", "label": "A股开盘"},
            {"date": registry_record["date"], "time": registry_record["time"],
             "role": "publisher_webpage_timestamp", "label": "财新网页刊发"},
        ],
        first_release_time=None, market_clock="completed_daily_ohlc_context",
        intraday_price_alignment=False,
        audience_takeaway="同日A股09:30开盘；财新网页刊发时间为09:43:10。该页面时间不证明全网首次发布时间。",
    )
    cue["event_refs"] = [deepcopy(event)]
    cue["secondary_layers"] = ["L1_MARKET"]
    cue["text_cue"]["lines"] = [
        "09:30｜A股开盘", "09:43:10｜财新网页刊发", "财新8月制造业PMI初值 47.1",
    ]
    cue["text_cue"]["source_line"] = "财新网｜网页时间"
    story = cue["camera_story_clock"]
    story["visual_variant"] = "pmi_dual_timeline"
    story["market_environment"] = {
        "date": "2015-08-21", "show_complete_daily_ohlc": True,
        "show_minute_level_prices": False,
    }
    _prepare_reading(cue, cue["text_cue"]["in_frame"], cue["end_frame_exclusive"] - 6, fps,
                     ("date_or_context", "date_or_context", "primary"))


def _market_window(cue, start, nframes, arrival):
    days = list(dict.fromkeys(key["date"] for key in cue["market_clock"]["keyframes"]))
    if not 0 <= arrival < nframes or (len(days) == 1) != (arrival == 0):
        raise ValueError(f"Invalid real trading-row movement budget: {cue['shot_id']}")
    if len(days) == 1:
        keys = [{"date": days[0], "frame_offset": 0}]
    else:
        keys = [{"date": day, "frame_offset": round(i * arrival / (len(days) - 1))}
                for i, day in enumerate(days)]
    keys.append({"date": days[-1], "frame_offset": nframes - 1})
    if any(a["frame_offset"] >= b["frame_offset"] for a, b in zip(keys, keys[1:])):
        raise ValueError(f"Cannot fit all real trading dates: {cue['shot_id']}")
    if cue["primary_anchor"]["date"] != days[-1]:
        raise ValueError(f"B17 capsule must anchor to the reached session: {cue['shot_id']}")
    cue.update(start_frame=start, end_frame_exclusive=start + nframes)
    cue["market_clock"]["keyframes"] = keys
    cue["primary_anchor"]["hit_frame"] = start + arrival
    cue["earth_orbit"]["hit_frame"] = start + arrival
    return start + arrival


def _focus_windows(cue, takeover_frame, mode):
    start = cue["start_frame"]
    windows = []
    if takeover_frame > start:
        windows.append({"start_frame": start, "end_frame_exclusive": takeover_frame,
                        "primary_focus": "L1_MARKET", "mode": "M1_MARKET"})
    windows.append({"start_frame": takeover_frame, "end_frame_exclusive": cue["end_frame_exclusive"],
                    "primary_focus": cue["primary_focus"], "mode": mode})
    cue["camera_story_clock"]["focus_windows"] = windows


def _market_capsule(cue, start, nframes, arrival, fps):
    hit = _market_window(cue, start, nframes, arrival)
    cue["camera"]["transition_seconds"] = 0.4
    cue["camera_story_clock"]["target"] = deepcopy(cue["camera"])
    _prepare_reading(cue, hit, cue["end_frame_exclusive"] - 6, fps)
    _focus_windows(cue, hit, "M2_KEY_POINT")


def _structure_cue(precursor, record, start, nframes, fps):
    event_id = record["metric_id"]
    etf = event_id == ETF_ID
    # Both layers begin after the prerequisite closing candle has already settled.
    cue = deepcopy(precursor)
    day = cue["primary_anchor"]["date"]
    expected_day = "2015-09-25" if etf else "2015-09-28"
    if day != expected_day or precursor["end_frame_exclusive"] != start:
        raise ValueError(f"Structure cue must follow its completed closing row: {event_id}")
    cue.update(
        shot_id="V102-B17-ETF" if etf else "V102-B17-TURNOVER",
        primary_focus="L3_MARKET_STRUCTURE", secondary_layers=["L1_MARKET"],
        source_ids=list(SOURCES[event_id]),
    )
    cue["market_clock"]["keyframes"] = [{"date": day, "frame_offset": 0}]
    hit = _market_window(cue, start, nframes, 0)
    cue["earth_orbit"]["reflection_pulse_seconds"] = 0
    text_in = hit + (12 if etf else 0)
    if etf:
        lines = ["9月7—22日 · 易方达创业板ETF份额", "12.37亿份 → 18.07亿份",
                 "+46.08%", "9月25日报道"]
        roles = ("date_or_context", "primary", "primary", "supporting")
        source_name = "据中国证券报援引深交所数据"
        cue["camera"]["visible_trading_days"] = 58
    else:
        lines = ["9月28日 · 全日", "沪深两市成交额", "4,044 亿元"]
        roles = ("date_or_context", "primary", "primary")
        source_name = "中新网／21世纪经济报道"
    cue["camera_story_clock"]["target"] = deepcopy(cue["camera"])
    cue["camera_story_clock"]["visual_variant"] = "etf" if etf else "turnover"
    cue["text_cue"].update(lines=lines, source_line=source_name)
    _prepare_reading(cue, text_in, cue["end_frame_exclusive"] - 6, fps, roles)
    _focus_windows(cue, text_in, "M3_EVENT_TAKEOVER")

    event = deepcopy(record)
    event.update(
        event_id=event_id, date=day, timezone="Asia/Shanghai", precision="day",
        registered_role=record["role"], activation_frame=text_in, publication_time=None,
        first_release_time=None, source_ids=list(SOURCES[event_id]), source_short=source_name,
        persistent_date_label_required=True, caption_must_not_follow_market_hud=True,
        market_freeze_after_hit=True,
        resolved_market_anchor={key: value for key, value in cue["primary_anchor"].items() if key != "hit_frame"},
        presentation_context="retrospective_on_report_date_no_claim_of_release_time" if etf
                             else "full_session_total_after_completed_close",
        no_causal_arrow=True,
    )
    if etf:
        event["observation_range"] = [record["observation_start"], record["observation_end"]]
    else:
        event["scope"] = "沪深两市合计成交额"
    cue["event_clock"] = event
    cue["event_refs"] = [deepcopy(event)]
    cue["link_geometry"]["event_ids"] = [event_id]
    cue["requires_renderer_capabilities"].append("independent_event_clock")
    return cue


def _replace_b17(decided, events):
    bounds = next(beat for beat in decided["beat_ranges"] if beat["id"] == "B17")
    b17 = [cue for cue in decided["cues"] if cue["beat_id"] == "B17"]
    if [cue["shot_id"] for cue in b17] != [f"V102-B17-{n:02d}" for n in range(1, 6)]:
        raise ValueError("Unexpected B17 base cues for the pinned visual decision.")
    if (bounds["start_frame"], bounds["end_frame_exclusive"]) != (5880, 6540):
        raise ValueError("Unexpected B17 playback window.")
    fps = decided["fps"]
    # Separate market structure from price captions. The existing HUD stays
    # visible, so each daily caption can be brief.
    timings = [
        (5880, 78, 17), (5958, 82, 24), (6040, 87, 30),
        (6277, 75, 18), (6466, 74, 17),
    ]
    for cue, (start, nframes, arrival) in zip(b17, timings, strict=True):
        _market_capsule(cue, start, nframes, arrival, fps)
    etf = _structure_cue(b17[2], events[ETF_ID], 6127, 150, fps)
    turnover = _structure_cue(b17[3], events[TURNOVER_ID], 6352, 114, fps)
    replacement = [*b17[:3], etf, b17[3], turnover, b17[4]]
    first = next(i for i, cue in enumerate(decided["cues"]) if cue["beat_id"] == "B17")
    decided["cues"][first:first + len(b17)] = replacement
    first_reveal = {}
    for cue in replacement:
        for key in cue["market_clock"]["keyframes"]:
            first_reveal.setdefault(key["date"], cue["start_frame"] + key["frame_offset"])
    for checkpoint in [bounds["primary_anchor"], *bounds["secondary_anchors"], *bounds["verified_price_checkpoints"]]:
        checkpoint["hit_frame"] = first_reveal[checkpoint["date"]]


def apply_visual_decisions(candidate: dict, registry: dict) -> dict:
    """Deep-copy the release candidate and apply only the approved B13/B17 changes."""
    if (candidate["package_version"], candidate["fps"], candidate["frame_count"]) != ("1.0.2", 30, 7200):
        raise ValueError("Visual decisions require the 240-second compiled V1.0.2 candidate.")
    events = {spec.get("event_id", spec.get("metric_id")): spec for spec in registry["events"]}
    if (
        (events[ETF_ID]["observation_start"], events[ETF_ID]["observation_end"],
         events[ETF_ID]["publication_date"], events[ETF_ID]["start_shares"],
         events[ETF_ID]["end_shares"], events[ETF_ID]["change_pct"],
         events[ETF_ID]["first_party_original_imported"])
        != ("2015-09-07", "2015-09-22", "2015-09-25", "12.37亿份", "18.07亿份", 46.08, False)
        or (events[TURNOVER_ID]["date"], events[TURNOVER_ID]["value"]) != ("2015-09-28", "4044亿元")
    ):
        raise ValueError("The T2 metric source register differs from the approved evidence.")
    decided = deepcopy(candidate)
    pmi = next(cue for cue in decided["cues"] if cue["shot_id"] == "V102-B13-02")
    _with_pmi_timeline(pmi, events[PMI_ID], decided["fps"])
    _replace_b17(decided, events)
    return decided
