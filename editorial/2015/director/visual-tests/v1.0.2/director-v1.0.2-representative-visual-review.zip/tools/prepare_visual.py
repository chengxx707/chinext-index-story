"""Resolve and validate the approved representative candidate before drawing."""

import argparse
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

from jsonschema import Draft202012Validator

from visual_candidate import apply_visual_decisions

EDITORIAL_INPUT = "16955b82ca0a2fbe63b2b168e5545fd701014c38"
RUNTIME_INPUT = "67a8cc6740c521675f71c6c733997e429681c3a2"
COMPILED_INPUT = "5e211d52afe376ff393a050493c4a1e780e780d9"
DIRECTOR = Path("editorial/2015/director")
COMPILED = DIRECTOR / "compiled/v1.0.2"
SCHEMA = Path("editorial/2015/releases/v1.0.1/director_timeline.schema.json")
FROZEN = (
    Path("data/cyb_daily.csv"), Path("config/production/film_master_v1.json"),
    Path("config/event_registry.json"), Path("assets/earth_cinematic.png"),
    Path("assets/earth_body.png"), Path("assets/reference/approved_visual_reference.png"),
)
BLOCKS = {"B01-B02": (0, 540), "B08-B10": (2280, 3600), "B16-B18": (5520, 7200)}


def git_blob(root, commit, path):
    return subprocess.check_output(["git", "show", f"{commit}:{path.as_posix()}"], cwd=root)


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def sha(body):
    return sha256(body).hexdigest()


def freeze_sources(root: Path, runtime_root: Path, package: Path) -> dict:
    immutable = (*FROZEN, *sorted(
        path.relative_to(root) for path in (root / SCHEMA.parent).rglob("*") if path.is_file()
    ))
    checks = {}
    for path in immutable:
        expected = git_blob(root, EDITORIAL_INPUT, path)
        if (root/path).read_bytes() != expected:
            raise ValueError(f"Input differs from the pinned editorial tree: {path}")
        checks[str(path)] = sha(expected)
    names = subprocess.check_output(["git","ls-tree","-r","--name-only",EDITORIAL_INPUT,str(SCHEMA.parent)],
                                   cwd=root,text=True).splitlines()
    if {str(path) for path in immutable if path.is_relative_to(SCHEMA.parent)} != set(names):
        raise ValueError("V1.0.1 release directory does not match the pinned tree")
    runtime_files = subprocess.check_output(["git","ls-tree","-r","--name-only",RUNTIME_INPUT,"src/chinext_v6",
                                           "tools/render_editorial_preview.py",str(SCHEMA)],cwd=root,text=True).splitlines()
    for name in runtime_files:
        path = Path(name)
        expected = git_blob(root, RUNTIME_INPUT, path)
        if (runtime_root/path).read_bytes() != expected:
            raise ValueError(f"Runtime differs from pinned published implementation: {name}")
        checks[f"runtime/{name}"] = sha(expected)
    for path in (Path("editorial/2015/HANDOFF_TO_CODEX.md"), DIRECTOR/"GPT_VISUAL_DECISIONS_V1.0.2.md",
                 DIRECTOR/"EVENT_CLOCK_REGISTER_V1.0.2.json",COMPILED/"director_candidate.json",
                 COMPILED/"candidate.schema.json", COMPILED/"README.md"):
        data = git_blob(root, EDITORIAL_INPUT, path)
        if (package/path).read_bytes() != data:
            raise ValueError(f"Inconsistent exported decision or configuration: {path}")
        checks[str(path)] = sha(data)
    for name in ("compile_candidate.py","event_audit.py","market_audit.py","runtime_audit.py","scene_plan.py"):
        path = COMPILED/"tools"/name
        data = git_blob(root, COMPILED_INPUT, path)
        if (package/path).read_bytes() != data:
            raise ValueError(f"Inconsistent published compiler library: {path}")
        checks[str(path)] = sha(data)
    return checks


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--repo-root", type=Path, default=Path.cwd())
    cli.add_argument("--runtime-root", type=Path, required=True)
    cli.add_argument("--inputs", type=Path, required=True)
    cli.add_argument("--output", type=Path, required=True)
    args = cli.parse_args()
    root, runtime_root, package, out = (getattr(args, name).resolve() for name in ("repo_root","runtime_root","inputs","output"))
    if not out.is_relative_to(root/"output"):
        cli.error("Use an ignored output/ subdirectory")
    out.mkdir(parents=True,exist_ok=True)
    hashes = freeze_sources(root, runtime_root, package)
    sys.path.insert(0,str(package/COMPILED/"tools"))
    from compile_candidate import project_legacy
    from runtime_audit import audit_runtime

    old = json.loads((package/COMPILED/"director_candidate.json").read_bytes())
    registry = json.loads((package/DIRECTOR/"EVENT_CLOCK_REGISTER_V1.0.2.json").read_bytes())
    candidate = apply_visual_decisions(old, registry)
    assert old["frame_count"] == candidate["frame_count"] == 7200
    assert old["fps"] == candidate["fps"] == 30
    copy_by_id = {cue["shot_id"]: cue for cue in old["cues"]}
    for cue in candidate["cues"]:
        if cue["beat_id"] != "B17" and cue["shot_id"] != "V102-B13-02":
            assert cue == copy_by_id[cue["shot_id"]], cue["shot_id"]
    schema = json.loads((package/COMPILED/"candidate.schema.json").read_bytes())
    Draft202012Validator.check_schema(schema)
    errors = [f"{item.json_path} {item.message}" for item in Draft202012Validator(schema).iter_errors(candidate)]
    legacy_schema = json.loads((runtime_root/SCHEMA).read_bytes())
    segments = project_legacy(candidate,legacy_schema)
    runtime = audit_runtime(candidate,segments,root,runtime_root)
    write(out/"candidate.json",candidate)
    write(out/"segments.json",segments)
    legacy_dir = out/"legacy"
    legacy_dir.mkdir(exist_ok=True)
    write(legacy_dir/"segments.json", [{key: value for key, value in seg.items() if key != "timeline"} for seg in segments])
    for segment in segments:
        write(legacy_dir/f'{segment["id"]}.json',segment["timeline"])
    write(out/"clock_revalidation.json",runtime)
    result = {"passed": not errors and runtime["passed"], "editorial_commit": EDITORIAL_INPUT,
              "compiled_base_commit": COMPILED_INPUT, "clock_implementation_commit": RUNTIME_INPUT,
              "input_sha256": hashes, "candidate_schema_errors": errors, "clock_passed": runtime["passed"],
              "transition_runtime_errors": runtime["runtime"]["errors"], "authorized_ranges": BLOCKS,
              "fps": candidate["fps"], "frame_count_as_timeline": candidate["frame_count"],
              "compiled_cue_count": len(candidate["cues"]), "render_executed_in_preparation": False}
    write(out/"intake.json",result)
    print(json.dumps({key:value for key,value in result.items() if key != "input_sha256"},ensure_ascii=False,indent=2))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
