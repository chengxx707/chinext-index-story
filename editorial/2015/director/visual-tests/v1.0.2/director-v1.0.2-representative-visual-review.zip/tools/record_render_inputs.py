"""Record the exact candidate and source bytes used by representative media."""

import argparse
from hashlib import file_digest
import json
from pathlib import Path


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--root",type=Path,required=True)
    cli.add_argument("--verify",action="store_true")
    options = cli.parse_args()
    root = options.root
    result = root/"result"
    intake = json.loads((result/"intake.json").read_bytes())
    if not intake["passed"]:
        raise RuntimeError("Input schema and legacy clock must pass before media work")
    paths = [*sorted((result/"legacy").glob("*.json")), result/"candidate.json",
             *[root/"work"/name for name in ("visual_overlay.py","render_visual.py","visual_candidate.py",
                                           "prepare_visual.py","make_review_media.py","review_playback.mjs")]]
    for key in intake["input_sha256"]:
        if key.startswith("runtime/"):
            paths.append(root/key)
        elif key.startswith(("data/","config/","assets/","editorial/2015/releases/")):
            paths.append(Path(key))
        else:
            paths.append(root/"inputs"/key)
    paths += sorted(Path("/usr/share/fonts/opentype/noto").glob("NotoSansCJK-*.ttc"))
    current = {}
    for path in paths:
        with path.open("rb") as handle:
            current[str(path)] = file_digest(handle,"sha256").hexdigest()
    record = result/"render_input_binding.json"
    if options.verify:
        before = json.loads(record.read_bytes())
        failures = sorted(key for key in before["inputs"].keys() | current.keys()
                          if before["inputs"].get(key) != current.get(key))
        before["verified_unchanged_after_render"] = not failures
        before["changed_paths"] = failures
        payload = before
    else:
        payload = {"inputs": current,"verified_unchanged_after_render": None}
    record.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+"\n")
    if options.verify and failures:
        raise RuntimeError(f"Render input digest changed: {failures}")


if __name__ == "__main__":
    main()
