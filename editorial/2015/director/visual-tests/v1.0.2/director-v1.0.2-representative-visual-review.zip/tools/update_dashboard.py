from datetime import date
from pathlib import Path
import re
import subprocess


BASE_COMMIT = "16955b82ca0a2fbe63b2b168e5545fd701014c38"
DASHBOARD_PATH = "docs/production/PROJECT-DASHBOARD.md"
REVIEW_PATH = "../../editorial/2015/director/visual-tests/v1.0.2/README.md"
PHOTO_REVIEW_COMMIT = "67a8cc6740c521675f71c6c733997e429681c3a2"
PHOTO_REVIEW_URL = (
    f"https://github.com/chengxx707/chinext-index-story/blob/{PHOTO_REVIEW_COMMIT}/"
    "review-downloads/wf-02r1-2015-visual/with-photo/README.md"
)
EXPECTED_SPANS = {(0, 540), (2280, 3600), (5520, 7200)}


def load_base_dashboard(repo_root: Path) -> str:
    """Read the dashboard from the authorized editorial input commit."""
    return subprocess.check_output(
        ["git", "show", f"{BASE_COMMIT}:{DASHBOARD_PATH}"],
        cwd=repo_root,
        encoding="utf-8",
    )


def update_dashboard(text: str, report: dict) -> str:
    """Publish the artifact state, keeping visual review as a separate gate.

    The report provides the Beijing date, encoded representative clips as
    frame_span/technical_passed mappings, and separate B13/B17 check booleans.
    Include only clips verified to exist as encoded media.
    """
    beijing_date = date.fromisoformat(report["date_beijing"]).isoformat()
    clips = {}
    for clip in report["representative_clips"]:
        span = tuple(clip["frame_span"])
        if span not in EXPECTED_SPANS or span in clips:
            raise ValueError(f"Unexpected or duplicate representative clip: {span}")
        clips[span] = clip["technical_passed"]
    b13_passed = report["b13_check_passed"]
    b17_passed = report["b17_check_passed"]
    if any(type(value) is not bool for value in (*clips.values(), b13_passed, b17_passed)):
        raise TypeError("Technical check results must be boolean values")

    encoded = len(clips)
    passes = encoded == len(EXPECTED_SPANS) and all(clips.values()) and b13_passed and b17_passed
    if passes:
        summary = "三段代表块已编码，B13 时间轴及 B17 两项 T2 接力已完成技术检查，待 GPT 与用户审片。"
        status = "已编码 3/3，技术检查通过，待 GPT 与用户审片"
    else:
        summary = f"代表块已编码 {encoded}/3 段，未通过和待验证项见执行报告。"
        status = f"已编码 {encoded}/3，技术检查结果见报告"

    old_photo_anchor = (
        "[WF-02R1审阅回执（固定提交371d11a）]"
        "(https://github.com/chengxx707/chinext-index-story/blob/"
        "371d11a358a42c0270506e301ca439c44358c9b6/"
        "review-downloads/wf-02r1-2015-visual/README.md)"
    )
    if text.count(old_photo_anchor) != 1:
        raise ValueError("Expected one prior WF-02R1 receipt link")
    text = text.replace(
        old_photo_anchor,
        f"[WF-02R1含图审阅回执（固定提交67a8cc6）]({PHOTO_REVIEW_URL})",
    )
    updates = (
        (
            r"^\*\*状态快照：[^\n]+\*\*$",
            f"**状态快照：{beijing_date}（北京时间）。V1.0.2 编译与五类结构门禁已通过。"
            f"{summary}完整 240 秒渲染待批准。**",
        ),
        (
            r"^\| Codex代表块视觉测试 \|[^\n]+\|$",
            f"| Codex代表块视觉测试 | **{status}** | "
            f"[代表块审片回执与下载]({REVIEW_PATH}) |",
        ),
    )
    for pattern, replacement in updates:
        text, count = re.subn(pattern, replacement, text, flags=re.MULTILINE)
        if count != 1:
            raise ValueError(f"Expected exactly one dashboard row matching {pattern!r}")
    return text
