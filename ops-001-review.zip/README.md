# OPS-001 审查包

- 源码位于 `orchestration/` 和 `tests/orchestration/`。完整工作区差异位于 `ops-001.patch`，包含所有 13 个新增文件，并已从开发基线应用验证。
- `git-metadata.json` 记录开发基线和 HEAD 的完整 SHA。`git-status.txt` 保存原始工作区状态。
- `output/ops-001-evidence/` 是 OPS-001 原始测试、Dry Run、实际执行与复跑证据。`run.json` 和 `repeat.json` 逐字节相同。
- `output/orchestration/` 是原始生产调度状态、日志、Manifest 和校验所需的产物。本次打包独立复核 3 份生产 Manifest 中的 16 项产物 SHA-256 与字节数。生产状态中未创建审批记录。
- `behavior-tests/` 保存本次重新运行的 6 项独立 pytest 用例及其临时状态。测试使用文本产物和测试批准人，覆盖重复运行、损坏产物重验、人工节点解锁、变更使审批失效和渲染开关门禁。此目录中的审批记录仅用于测试。

日志和运行报告保留执行时的绝对路径。生产产物的 Manifest 路径以包内 `output/orchestration/` 为基准。
